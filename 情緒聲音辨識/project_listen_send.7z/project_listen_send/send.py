import pyaudio  # 引入pyaudio套件來紀錄聲音
import wave  # 引入wave套件來擴充可生成.wav檔
from ctypes import *
import emd

CHUNK = 512  # wav文件是由若干個CHUNK組成的，CHUNK我們就理解成數據包或者數據片段。
FORMAT = pyaudio.paInt16  # 表示我們使用量化位數 16位來進行錄音
CHANNELS = 1  # 代表的是聲道，1是單聲道，2是雙聲道
RATE = 44100  # 採樣率 一秒內對聲音信號的採集次數，常用的有8kHz, 16kHz, 32kHz, 48kHz,
# 11.025kHz, 22.05kHz, 44.1kHz。
RECORD_SECONDS = 5  # 錄製時間這裏設定了5秒

# 設定檔案名稱
WAVE_OUTPUT_FILENAME = "sounds.wav"
count = 0
while count <1:
    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

    print("recording...")
    frames = []  # 定義一個列表
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):  # 循環，採樣率 44100 / 1024 * 5
        data = stream.read(CHUNK)  # 讀取chunk個字節 保存到data中
        frames.append(data)  # 向列表frames中添加數據data

    print("done")
    stream.stop_stream()
    stream.close()  # 關閉
    p.terminate()  # 終結

    wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    wf.close()

    # DB
    from pydub import AudioSegment
    import math

    sound = AudioSegment.from_file('sounds.wav')

    RMS = sound.rms
    DB = 20 * math.log10(RMS)
    print("DB =", DB)

    #引入套件requests
    import requests
    import wave
    from django.core.files import File
    from package import Cloud_package
    import time

    method = "POST"
    if DB > 70:
        path = r'sounds.wav'
        # r = Cloud_package.to_img(path)
        # print(r)


        wav_file = File(open(path, 'rb'))
        # url_Test = ' http://127.0.0.1:8000/Test/'
        url_Test = ' http://25.60.164.203:8000/Test/'
        # file = {'wav_file': wav_file, 'wav_img': wav_img, 'imf1': imf1_img, 'imf2': imf2_img, 'imf3': imf3_img}
        file = {'wav_file': wav_file}
        my_data = {'username': 'kuo'}
        print('start')
        r2 = requests.post(url_Test, data=my_data, files=file)
        print(r2.content)







