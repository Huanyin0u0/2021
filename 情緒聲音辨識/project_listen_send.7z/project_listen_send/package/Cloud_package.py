import librosa
import librosa.display
import numpy as np
import emd
import matplotlib.pyplot as plt
import requests


# 0. 載入模型
# 1. 把聲音分成IMF1、IMF2、IMF3
# 2. 把IMF轉換成不同的頻譜
# 3. 用個別的Model進行預測
# 4. 進行統計各分量的結果，算出最後的結果
# 5. 回傳結果

# 邊緣裝置

def to_img(upload_path): # 控制台
    decompose(upload_path)
    process_IMF1()
    process_IMF2()
    process_IMF3()
    return 'finish convert img'

def decompose(file_path):
    global imf1
    global imf2
    global imf3
    global audio_rate
    #讀入音檔
    au, sr = librosa.load(file_path, sr=None)  # 載入波形檔, 不重複取樣
    wav_to_img(au)
    imf = emd.sift.sift(au)
    imf1 = imf[:,0].astype(np.float32)
    imf2 = imf[:,1].astype(np.float32)
    imf3 = imf[:,2].astype(np.float32)
    audio_rate = sr

def wav_to_img(au):
    plt.figure()
    plt.plot(au)
    plt.axis('off')
    plt.savefig('imfs/wav.png')
    plt.close('all')

def process_IMF1():
    #IMF1頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.stft(imf1)                 # 做短期傅立葉
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='jet')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf1.png')
    plt.close('all')

def process_IMF2():
    # IMF2頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.cqt(imf2)  # 做cqt
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='nipy_spectral')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf2.png')
    plt.close('all')

def process_IMF3():
    # IMF3頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.cqt(imf2)  # 做cqt
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='rainbow')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf3.png')
    plt.close('all')











