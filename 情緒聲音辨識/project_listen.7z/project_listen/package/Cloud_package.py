import librosa
import librosa.display
import numpy as np
import emd
import matplotlib.pyplot as plt
from tensorflow.python.keras.models import load_model
from tensorflow.python.keras.preprocessing import image
import requests

from DataAnalyze import DataAnalyze

# 0. 載入模型
# 1. 把聲音分成IMF1、IMF2、IMF3
# 2. 把IMF轉換成不同的頻譜
# 3. 用個別的Model進行預測
# 4. 進行統計各分量的結果，算出最後的結果
# 5. 回傳結果

# 邊緣裝置

def to_img(upload_path): # 控制台
    decompose(upload_path)
    process_IMF1()
    process_IMF2()
    process_IMF3()
    return 'finish convert img'

def decompose(file_path):
    global imf1
    global imf2
    global imf3
    global audio_rate
    #讀入音檔
    au, sr = librosa.load(file_path, sr=None)  # 載入波形檔, 不重複取樣
    wav_to_img(au)
    imf = emd.sift.sift(au)
    imf1 = imf[:,0].astype(np.float32)
    imf2 = imf[:,1].astype(np.float32)
    imf3 = imf[:,2].astype(np.float32)
    audio_rate = sr

def wav_to_img(au):
    plt.figure()
    plt.plot(au)
    plt.axis('off')
    plt.savefig('imfs/wav_temp.png')
    plt.close('all')

def process_IMF1():
    #IMF1頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.stft(imf1)                 # 做短期傅立葉
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='jet')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf1_temp.png')
    plt.close('all')

def process_IMF2():
    # IMF2頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.cqt(imf2)  # 做cqt
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='nipy_spectral')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf2_temp.png')
    plt.close('all')

def process_IMF3():
    # IMF3頻譜轉換
    plt.figure(figsize=(2.24, 2.24))
    plt.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
    X = librosa.cqt(imf2)  # 做cqt
    Xdb = librosa.amplitude_to_db(abs(X))  # 能量轉換為 dB
    librosa.display.specshow(Xdb,
                             sr=audio_rate,
                             x_axis='time',
                             y_axis='hz',
                             cmap='rainbow')  # 著色 : rainbow gist_ncar jet nipy_spectral
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.savefig('imfs/imf3_temp.png')
    plt.close('all')

# 伺服器

def predict(picture_imf1, picture_imf2, picture_imf3): # 控制台
    # 傳來的是圖片地址 
    record, emotion_list, temp = imf_predict(picture_imf1, picture_imf2, picture_imf3)
    message, temp = model_vote(record, emotion_list, temp)
    #message = '辨識結果為 : '+message
    return message, temp

def download_model():

    global IMF1_model
    global IMF2_model
    global IMF3_model

    IMF1_model = load_model('h5/IMF1/IMF1.h5')
    IMF2_model = load_model('h5/IMF2/IMF2_CQT_NS.h5')
    IMF3_model = load_model('h5/IMF3/IMF3_CQT_Rainbow.h5')


def imf_predict(picture_imf1, picture_imf2, picture_imf3): #切忌不可以隨便轉變型態，會對預測結果有影響
    emotion_list = ['Cry', 'Laugh', 'Scream', 'Sigh', 'Wail']
    input_shape = (112, 112, 3)
    record = []
    
    #imf1預測
    # imf1_img = image.load_img('imfs/imf1.png', target_size=(112, 112))
    imf1_img = image.load_img(picture_imf1, target_size=(112, 112))
    x = image.img_to_array(imf1_img)
    x = np.expand_dims(x, axis=0)
    x = x.reshape((-1,) + input_shape) / 255.0
    imf1_picture = x #切忌不可以隨便轉變型態，會對預測結果有影響
    temp = IMF1_model.predict(imf1_picture)
    imf1_index = np.argmax(temp)
    # print('辨識ok')
    imf1_result = str(emotion_list[imf1_index])
    record.append(imf1_result) #分量1的結果
    
    #imf2預設
    imf2_img = image.load_img(picture_imf2, target_size=(112, 112))
    x = image.img_to_array(imf2_img)
    x = np.expand_dims(x, axis=0)
    x = x.reshape((-1,) + input_shape) / 255.0
    imf2_picture = x #切忌不可以隨便轉變型態，會對預測結果有影響
    imf2_index = np.argmax(IMF2_model.predict(imf2_picture))
    imf2_result = str(emotion_list[imf2_index])
    record.append(imf2_result) #分量2的結果
    
    #imf3預測
    imf3_img = image.load_img(picture_imf3, target_size=(112, 112))
    x = image.img_to_array(imf3_img)
    x = np.expand_dims(x, axis=0)
    x = x.reshape((-1,) + input_shape) / 255.0
    imf3_picture = x #切忌不可以隨便轉變型態，會對預測結果有影響
    imf3_index = np.argmax(IMF3_model.predict(imf3_picture))
    imf3_result = str(emotion_list[imf3_index])
    record.append(imf3_result)  # 分量3的結果
    
    #回傳結果
    list1 = []
    list1.append(imf1_picture.shape)
    list1.append(imf2_picture.shape)
    list1.append(imf3_picture.shape)
    return record, emotion_list, temp #,list1

def model_vote(record, emotion_list, temp):
   token = '2FOB4XKugCIh8JehPsu8kDTsJi6zVpJHuRifcdBvzlK'
   emotion_list = ['Cry', 'Laugh', 'Scream', 'Sigh', 'Wail']
   cry_count = 0
   laugh_count = 0
   scream_count = 0
   sigh_count = 0
   wail_count = 0

   imf1_result = record[0]
   imf2_result = record[1]
   imf3_result = record[2]
   print('imf1_result= ', imf1_result)
   print('imf2_result= ', imf2_result)
   print('imf3_result= ', imf3_result)
   list1 = [imf1_result, imf2_result, imf3_result]

   for emotion in list1:
       if emotion == 'Cry':
           cry_count = cry_count + 1
       elif emotion == 'Laugh':
           laugh_count = laugh_count + 1
       elif emotion == 'Scream':
           scream_count = scream_count + 1
       elif emotion == 'Sigh':
           sigh_count = sigh_count + 1
       else:
           wail_count = wail_count + 1

   list2 = [cry_count, laugh_count, scream_count, sigh_count, wail_count]
   vote_number = max(list2)
   '''if vote_number == 1:
       final_result = imf1_result
       if final_result == 'Cry':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/cry.jpg')
       elif final_result == 'Laugh':
           lineNotify(token=token, msg='陳小春現在感覺到' + final_result, picURI='static/images/laugh.jpg')
       elif final_result == 'Scream':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/scream.jpg')
       elif final_result == 'Sigh':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/sigh.jpg')
       else:
           lineNotify(token=token, msg='陳小春現在感覺到' + final_result, picURI='static/images/wall.jpg')
       return final_result
   '''
   if vote_number > 1:
       max_index = np.argmax(list2) #找出最大票數的index
       final_result = emotion_list[max_index]
       if final_result == 'Cry':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/cry.jpg')
       elif final_result == 'Laugh':
           lineNotify(token=token, msg='陳小春現在感覺到' + final_result, picURI='static/images/laugh.jpg')
       elif final_result == 'Scream':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/scream.jpg')
       elif final_result == 'Sigh':
           lineNotify(token=token, msg='陳小春現在感覺到'+final_result, picURI='static/images/sigh.jpg')
       else:
           lineNotify(token=token, msg='陳小春現在感覺到' + final_result, picURI='static/images/wail.jpg')
       return final_result, temp

'''
def predict(upload_path, imf1_model, imf2_model, imf3_model):
    global IMF1_model
    global IMF2_model
    global IMF3_model
    IMF1_model = imf1_model
    IMF2_model = imf2_model
    IMF3_model = imf3_model
    decompose(upload_path)
    process_IMF1()
    process_IMF2()
    process_IMF3()
    record, emotion_list = imf_predict()
    message = model_vote(record,emotion_list)
    #message = '辨識結果為 : '+message
    return message
'''



def lineNotify(token, msg, picURI): # picURI是圖片
    url = "https://notify-api.line.me/api/notify"
    headers = {
        "Authorization": "Bearer " + token
    }
    payload = {'message': msg}
    files = {'imageFile': open(picURI, 'rb')}
    r = requests.post(url, headers=headers, params=payload, files=files)
    return r.status_code

print('ok')











