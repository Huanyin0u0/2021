from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


# Create your models here.

# Server的
class Data(models.Model):
    file = models.FileField(upload_to='data')  # wav音檔


# Web的
class a(models.Model):
    EMOTION_TYPE = (
        ('Happy', 'Happy'),
        ('Sad', 'Sad'),
        ('Scream', 'Scream'),
        ('Sigh', 'Sigh'),
        ('Wail', 'Wail'),
    )

    emotion = models.CharField(max_length=255, choices=EMOTION_TYPE, default='Happy')


class User_Data(models.Model):
    EMOTION_TYPE = (  # choice是一個2維元組，第一個是電腦真實存儲辨識的值，第2個是網頁顯示的資料
        ('Happy', 'Happy'),
        ('Cry', 'Cry'),
        ('Scream', 'Scream'),
        ('Sigh', 'Sigh'),
        ('Wail', 'Wail'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE)

    emotion = models.CharField(max_length=255, choices=EMOTION_TYPE, default='Happy')
    # p = User_Data(user=user, emotion='S')
    # p.emotion >> 'S'
    # p.get_emotion_display() >> 'Sad'

    wav_file = models.FileField(upload_to='static/wav/Data/', blank=True)

    wav_img = models.ImageField(upload_to='static/images/DataBase_Data/', blank=True)

    imf1_img = models.ImageField(upload_to='static/images/DataBase_Data/', blank=True)

    imf2_img = models.ImageField(upload_to='static/images/DataBase_Data/', blank=True)

    imf3_img = models.ImageField(upload_to='static/images/DataBase_Data/', blank=True)

    # auto_now_add=True

    pub_Date = models.DateField(auto_now_add=True)

    pub_time = models.TimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username


class DataAnalyze_Data(models.Model):
    data = models.ForeignKey(User_Data, on_delete=models.CASCADE)
    LineChart = models.ImageField(upload_to='static/images/Data_Analyz/', blank=True)
    Statistic = models.ImageField(upload_to='static/images/Data_Analyze/', blank=True)
    PieChart = models.ImageField(upload_to='static/images/Data_Analyze/', blank=True)


class test_image(models.Model):
    img = models.ImageField(upload_to='static/images/test/', null=True)
    pub_Date = models.DateField(auto_now_add=True)
    pub_time = models.TimeField(auto_now_add=True)