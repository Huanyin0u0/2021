from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.handlers.wsgi import WSGIRequest
from django.core.files import File
# from django.contrib.auth.models import User
from DataAnalyze import DataAnalyze
from django.db.models import Q
from django.core.files import File

# 驗證
from django.contrib.auth import authenticate, login, logout

# myapp
from server import models
from .form import RegisterForm, LoginForm

# EMD分解程式
from package import Cloud_package

# 處理上傳的程式
from werkzeug.utils import secure_filename
import os
import json

# 分頁
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# 統計
from DataAnalyze import DataAnalyze

# 追蹤錯誤 https://dotblogs.com.tw/caubekimo/2018/09/17/145733
import sys
import traceback

import cv2


# Create your views here.

# Server的部分

def statistics_DangerCount(data):
    day_DangerCount = 0
    emotion_list = ['Sad', 'Scream', 'Sigh', 'Wail']
    for d in data:
        if d.emotion in emotion_list:
            day_DangerCount = day_DangerCount + 1
    return day_DangerCount


def create_Linechart(user):  # 折線圖

    x = []
    y = []

    # 基礎資料
    data = models.User_Data.objects.filter(user=user)
    date = models.User_Data.objects.filter(user=user).values('pub_Date').order_by('-pub_Date').distinct()[:4]

    # today的資料統計
    today = [date[0]['pub_Date'].year, date[0]['pub_Date'].month, date[0]['pub_Date'].day]  # 取得日期，接下來要取得該日期的所有資料
    today_date = str(today[0]) + '-' + str(today[1]) + '-' + str(today[2])
    today_DangerCount = statistics_DangerCount(
        data.filter(Q(pub_Date__year=today[0]), Q(pub_Date__month=today[1]), Q(pub_Date__day=today[2])))
    x.append(today_date)
    y.append(today_DangerCount)

    # yesterday_1
    if len(date) >= 2:
        yesterday_1 = [date[1]['pub_Date'].year, date[1]['pub_Date'].month, date[1]['pub_Date'].day]
        yesterday_1_date = str(yesterday_1[0]) + '-' + str(yesterday_1[1]) + '-' + str(yesterday_1[2])
        yesterday_1_DangerCount = statistics_DangerCount(
            data.filter(Q(pub_Date__year=yesterday_1[0]), Q(pub_Date__month=yesterday_1[1]),
                        Q(pub_Date__day=yesterday_1[2])))
        x.append(yesterday_1_date)
        y.append(yesterday_1_DangerCount)

    # yesterday_2
    if len(date) >= 3:
        yesterday_2 = [date[2]['pub_Date'].year, date[2]['pub_Date'].month, date[2]['pub_Date'].day]
        yesterday_2_date = str(yesterday_2[0]) + '-' + str(yesterday_2[1]) + '-' + str(yesterday_2[2])
        yesterday_2_DangerCount = statistics_DangerCount(
            data.filter(Q(pub_Date__year=yesterday_2[0]), Q(pub_Date__month=yesterday_2[1]),
                        Q(pub_Date__day=yesterday_2[2])))
        x.append(yesterday_2_date)
        y.append(yesterday_2_DangerCount)

    # yesterday_3
    if len(date) >= 4:
        yesterday_3 = [date[3]['pub_Date'].year, date[3]['pub_Date'].month, date[3]['pub_Date'].day]
        yesterday_3_date = str(yesterday_3[0]) + '-' + str(yesterday_3[1]) + '-' + str(yesterday_3[2])
        yesterday_3_DangerCount = statistics_DangerCount(
            data.filter(Q(pub_Date__year=yesterday_3[0]), Q(pub_Date__month=yesterday_3[1]),
                        Q(pub_Date__day=yesterday_3[2])))
        x.append(yesterday_3_date)
        y.append(yesterday_3_DangerCount)

    # user資料
    name = user.username
    x.reverse()
    y.reverse()
    DataAnalyze.LineChart(y, x, name)


def create_statistic(user):  # 統計圖，7天內的統計資料
    # 基礎資料
    name = user.username
    data = models.User_Data.objects.filter(user=user)
    date = models.User_Data.objects.filter(user=user).values('pub_Date').order_by('-pub_Date').distinct()[:7]
    today = date[0]['pub_Date']
    final_day = date[len(date) - 1]['pub_Date']
    target_data = data.filter(pub_Date__range=[final_day, today])
    happy_count = target_data.filter(emotion__iexact='Happy').count()
    sad_count = target_data.filter(emotion__iexact='sad').count()
    scream_count = target_data.filter(emotion__iexact='scream').count()
    sigh_count = target_data.filter(emotion__iexact='sigh').count()
    wail_count = target_data.filter(emotion__iexact='wail').count()
    DataAnalyze.Statistical([happy_count, sad_count, scream_count, sigh_count, wail_count], name)

'''
@csrf_exempt
def Test(request: WSGIRequest):
    print('-----------------------------------')
    if request.method == 'GET':
        print("get GET request: ", request)
        return JsonResponse({'first': 'content', 'second': 'test'})
    elif request.method == 'POST':
        # Httprequest傳送資料
        # requests.post(url_Test, data=my_data, files=file)，文字資料放data，檔案放files
        try:
            username = request.POST['username']
            wav_file = request.FILES.get('wav_file')
            wav_img = request.FILES.get('wav_img')  # 取得檔案，.name獲取檔名
            imf1 = request.FILES.get('imf1')
            imf2 = request.FILES.get('imf2')
            imf3 = request.FILES.get('imf3')

            user = models.User.objects.get(username=username)
            # 產生新檔案並且存到資料庫
            new_data = models.User_Data.objects.create(user=user, emotion='Happy', wav_file=wav_file, wav_img=wav_img,
                                                       imf1_img=imf1, imf2_img=imf2, imf3_img=imf3)
            # create 會自動存到資料庫並且返回操作對象

            picture_imf1 = str(new_data.imf1_img)
            picture_imf2 = str(new_data.imf2_img)
            picture_imf3 = str(new_data.imf3_img)

            message, temp = Cloud_package.predict(picture_imf1, picture_imf2, picture_imf3)
            # print(temp.shape)
            temp = temp[0]

            # 記錄心情
            new_data.emotion = message

            # 畫統計圖
            create_Linechart(user)
            create_statistic(user)
            DataAnalyze.PieChart(temp, 'temp')

            LineChart = File(open('line2.jpg', 'rb'))
            Statistic = File(open('statistic2.jpg', 'rb'))
            PieChart = File(open('pie2.jpg', 'rb'))
            data_analyze = models.DataAnalyze_Data.objects.create(data=new_data, LineChart=LineChart,
                                                                  Statistic=Statistic, PieChart=PieChart)
            new_data.save()

            # 辨識
            print('照護對象 : 陳小春處於情緒',message)
            return JsonResponse({'status': message})
        except Exception as e:
            error_class = e.__class__.__name__  # 取得錯誤類型
            detail = e.args[0]  # 取得詳細內容
            cl, exc, tb = sys.exc_info()  # 取得Call Stack
            lastCallStack = traceback.extract_tb(tb)[-1]  # 取得Call Stack的最後一筆資料
            fileName = lastCallStack[0]  # 取得發生的檔案名稱
            lineNum = lastCallStack[1]  # 取得發生的行號
            funcName = lastCallStack[2]  # 取得發生的函數名稱
            errMsg = "File \"{}\", line {}, in {}: [{}] {}".format(fileName, lineNum, funcName, error_class, detail)
            print(errMsg)
            return JsonResponse({'status': 'something fail'})

        # create_Linechart(user)
        # create_statistic(user)
        return JsonResponse({'status': 'over'})

    else:
        print("get unknown request: ", request)
        return JsonResponse({'status': 'no, I don\'t know it.'}
'''

@csrf_exempt
def Test(request: WSGIRequest):
    print('-----------------------------------')
    if request.method == 'GET':
        print("get GET request: ", request)
        return JsonResponse({'first': 'content', 'second': 'test'})
    elif request.method == 'POST':
        # Httprequest傳送資料
        # requests.post(url_Test, data=my_data, files=file)，文字資料放data，檔案放files
        try:
            # 使用者
            username = request.POST['username']
            user = models.User.objects.get(username=username)

            # 音檔
            wav_file = request.FILES.get('wav_file')
            models.User_Data.objects.create(user=user, emotion='Happy', wav_file=wav_file)
            new_data = models.User_Data.objects.last()
            wave_file_path = new_data.wav_file # 路徑

            # 分解出圖片
            Cloud_package.to_img(wave_file_path)


            # 取出圖片
            wav_img = File(open('imfs/wav_temp.png', 'rb'))
            imf1 = File(open('imfs/imf1_temp.png', 'rb'))
            imf2 = File(open('imfs/imf2_temp.png', 'rb'))
            imf3 = File(open('imfs/imf3_temp.png', 'rb'))


            # 存檔
            new_data.wav_img = wav_img
            new_data.imf1_img = imf1
            new_data.imf2_img = imf2
            new_data.imf3_img = imf3

            # 產生新檔案並且存到資料庫
            # create 會自動存到資料庫並且返回操作對象
            picture_imf1 = str(new_data.imf1_img) # 路徑
            picture_imf2 = str(new_data.imf2_img)
            picture_imf3 = str(new_data.imf3_img)

            message, temp = Cloud_package.predict(picture_imf1, picture_imf2, picture_imf3)
            # print(temp.shape)
            temp = temp[0]

            # 記錄心情
            new_data.emotion = message

            # 畫統計圖
            create_Linechart(user)
            create_statistic(user)
            DataAnalyze.PieChart(temp, 'temp')

            LineChart = File(open('line2.jpg', 'rb'))
            Statistic = File(open('statistic2.jpg', 'rb'))
            PieChart = File(open('pie2.jpg', 'rb'))
            data_analyze = models.DataAnalyze_Data.objects.create(data=new_data, LineChart=LineChart,
                                                                  Statistic=Statistic, PieChart=PieChart)
            new_data.save()
            # 辨識
            print('照護對象 : 陳小春處於情緒',message)
            return JsonResponse({'status': message})
        except Exception as e:
            error_class = e.__class__.__name__  # 取得錯誤類型
            detail = e.args[0]  # 取得詳細內容
            cl, exc, tb = sys.exc_info()  # 取得Call Stack
            lastCallStack = traceback.extract_tb(tb)[-1]  # 取得Call Stack的最後一筆資料
            fileName = lastCallStack[0]  # 取得發生的檔案名稱
            lineNum = lastCallStack[1]  # 取得發生的行號
            funcName = lastCallStack[2]  # 取得發生的函數名稱
            errMsg = "File \"{}\", line {}, in {}: [{}] {}".format(fileName, lineNum, funcName, error_class, detail)
            print(errMsg)
            return JsonResponse({'status': 'something fail'})

        # create_Linechart(user)
        # create_statistic(user)
        return JsonResponse({'status': 'over'})
    else:
        print("get unknown request: ", request)
        return JsonResponse({'status': 'no, I don\'t know it.'})

@csrf_exempt
def Test2(request: WSGIRequest):
    if request.method == 'POST':
        username = request.POST['username']
        wav = request.FILES.get('wav')  # 取得檔案，.name獲取檔名
        imf1 = request.FILES.get('imf1')
        imf2 = request.FILES.get('imf2')
        imf3 = request.FILES.get('imf3')
        img = request.FILES.get('img')
        try:
            user = models.User.objects.get(username=username)
            new_data = models.test_image.objects.create(img=img)
            new_data = models.User_Data.objects.create(user=user, emotion='Happy', wav_img=wav, imf1_img=imf1,
                                                       imf2_img=imf2, imf3_img=imf3)
            return JsonResponse({'status': 'ok'})
        except:
            return JsonResponse({'status': 'no user'})
    else:
        print("get unknown request: ", request)
        return JsonResponse({'status': 'no, I don\'t know it.'})


@csrf_exempt
def Server_receive(request: WSGIRequest):
    print('-----------------------------------')
    if request.method == 'GET':
        print("get GET request: ", request)
        return JsonResponse({'first': 'content', 'second': 'test'})
    elif request.method == 'POST':
        # file = json.loads(request.body).get("key")
        file_obj = request.FILES.get('myfile')  # 取得檔案，.name獲取檔名
        data = models.Data(file=file_obj)  # 要先在models建好資料表
        data.save()  # 把資料存在本地端
        upload_path = 'data/' + file_obj.name
        global message
        # message = predict(upload_path, IMF1_model, IMF2_model, IMF3_model)
        if file_obj == None:
            return JsonResponse({'status': 'not ok'})
        else:
            return JsonResponse({'status': file_obj.name})
    else:
        print("get unknown request: ", request)
        return JsonResponse({'status': 'no, I don\'t know it.'})


@csrf_exempt
def inital():
    print('Start inital .....')
    Cloud_package.download_model()
    print('OK, Finish inital .....')
    # return JsonResponse({'Status': 'model loading'})


# 網站的部分

# 註冊
def sign_up(request):
    form = RegisterForm()

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login')
        else:
            message = '註冊失敗'

    return render(request, 'register.html', locals())


# 登入
def sign_in(request):
    message = None
    form = LoginForm()

    if request.method == 'POST':
        username = request.POST.get("username100")  # <input name='username100'>是靠name去取得對應的資料
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)  # 使用者
        if user is not None:
            login(request, user)  # 存入session
            return redirect('/index')
        else:
            message = '登入失敗，請重新登入'

    return render(request, 'login.html', locals())


def sign_out(request):
    logout(request)
    return redirect('/logout')


# 資料頁面

def index(request, data_id=None):
    if request.user.is_authenticated:
        user = request.user  # 從session取出使用者
    try:
        # user = User.objects.get(username='demo') 有這行 user = request.user就不用了
        all_data = models.User_Data.objects.filter(user=user).order_by('-pub_Date', '-pub_time')

        # 分頁顯示
        paginator = Paginator(all_data, 10)
        p = request.GET.get('p')
        try:
            polls = paginator.page(p)  # page()是分頁的重要參數，取得分頁物件
        except PageNotAnInteger:
            polls = paginator.page(1)
        except EmptyPage:
            polls = paginator.page(paginator.num_pages)

        # 資料顯示
        if data_id is not None:  # 有指定分頁
            try:
                user_data = models.User_Data.objects.get(id=data_id)  # 特定一筆資料
                emotion = user_data.emotion
                if emotion == 'Cry':
                    e_img = 'cry.jpg'
                elif emotion == 'Laugh':
                    e_img = 'laugh.jpg'
                elif emotion == 'Scream':
                    e_img = 'scream.jpg'
                elif emotion == 'Sigh':
                    e_img = 'sigh.jpg'
                else:
                    e_img = 'wail.jpg'
                data_analyze = models.DataAnalyze_Data.objects.get(data=user_data)
            except:
                pass
        else:
            try:
                data_id = all_data[0].id  # 一開始顯示最新的資料
                user_data = models.User_Data.objects.get(id=data_id)
                emotion = user_data.emotion
                if emotion == 'Cry':
                    e_img = 'cry.jpg'
                elif emotion == 'Laugh':
                    e_img = 'laugh.jpg'
                elif emotion == 'Scream':
                    e_img = 'scream.jpg'
                elif emotion == 'Sigh':
                    e_img = 'sigh.jpg'
                else:
                    e_img = 'wail.jpg'
                data_analyze = models.DataAnalyze_Data.objects.get(data=user_data)
            except:
                pass

    except:
        message = '尚無使用者資料'

    return render(request, 'listen_index.html', locals())














