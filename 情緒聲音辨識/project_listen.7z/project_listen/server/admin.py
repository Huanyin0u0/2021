from django.contrib import admin
from server import models

# Register your models here.

class PostAdmin(admin.ModelAdmin):
    list_display = ['user', 'emotion', 'pub_Date','pub_time']
    ordering = ('-pub_Date', )

# admin.site.register(models.a)
# admin.site.register(models.Data)

admin.site.register(models.User_Data, PostAdmin)
admin.site.register(models.test_image)
admin.site.register(models.DataAnalyze_Data)

